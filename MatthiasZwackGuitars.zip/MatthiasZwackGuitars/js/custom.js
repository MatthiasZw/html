/* Start AOS */
AOS.init({
    duration:800,
    easing:'ease-out',
    offset:200,
    disable:'mobile'
});
